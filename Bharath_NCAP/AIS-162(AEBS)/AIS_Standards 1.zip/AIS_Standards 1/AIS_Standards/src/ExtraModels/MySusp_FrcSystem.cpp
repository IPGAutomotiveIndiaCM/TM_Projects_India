/*
 *****************************************************************************
 *  CarMaker - Version 15.0
 *  Virtual Test Driving Tool
 *
 *  Copyright ©1998-2025 IPG Automotive GmbH. All rights reserved.
 *  www.ipg-automotive.com
 *****************************************************************************
 *
 * Simple suspension Model for Suspension FrcSystem
 *
 * Add the declaration of the register function to one of your header files,
 * for example to User.h and call it in User_Register()
 *
 *    int Susp_FrcSystem_Register_MyModel (void);
 *
 *****************************************************************************
 */

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "CarMaker.h"
#include "Car/Car.h"
#include "Car/Vehicle_Car.h"
#include "MyModels.h"
#include "Log.h"

static char const ThisModelClass[] = "Susp_FrcSystem";
static char const ThisModelKind[]  = "MyModel";
static int const  ThisVersionId    = 1;

#define N_SUSPENSIONS 4

/* model parameters */
struct tMyModel {
    struct tMyFrcSpring {
        double len0;
        double Frc0;
        double dFrc_dl;
    } Spring[N_SUSPENSIONS];

    struct tMyFrcDamp {
        double dFrc_dlp;
    } Damp_Push[N_SUSPENSIONS], Damp_Pull[N_SUSPENSIONS];

    struct tMyFrcBuffer {
        double len0;
        double dFrc_dl;
    } Buf_Push[N_SUSPENSIONS], Buf_Pull[N_SUSPENSIONS];

    struct tMyFrcStabi {
        double dFrc_dl;
    } Stabi[N_SUSPENSIONS];
};

static void
MyModel_DeclQuants_dyn(struct tMyModel *mp, int park)
{
    static struct tMyModel MyModel_Dummy;
    memset(&MyModel_Dummy, 0, sizeof(struct tMyModel));
    if (park) {
        mp = &MyModel_Dummy;
    }

    /* Define here dict entries for dynamically allocated variables. */
}

static void
MyModel_DeclQuants(void *MP, char const *Ident)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    if (mp == NULL) {
        /* Define here dict entries for non-dynamically allocated (static) variables. */

    } else {
        MyModel_DeclQuants_dyn(mp, 0);
    }
}

static void *
MyModel_New(struct tInfos *Inf, void *pCfgIF, char const *KindKey, char const *IdKey)
{
    tSusp_FrcSystemCfgIF *CfgIF = (tSusp_FrcSystemCfgIF *) pCfgIF;
    struct tMyModel      *mp    = NULL;
    int                   iS, n, VersionId = 0;
    char                  MsgPre[64];
    char const           *ModelKind;
    double               *Param[4] = {NULL, NULL, NULL, NULL};

    if ((ModelKind = SimCore_GetKindInfo(Inf, ModelClass_Susp_FrcSystem, KindKey, 0, ThisVersionId, &VersionId))
        == NULL) {
        return NULL;
    }

    sprintf(MsgPre, "%s %s", ThisModelClass, ThisModelKind);

    mp = (struct tMyModel *) calloc(1, sizeof(*mp));

    for (iS = 0; iS < N_SUSPENSIONS; iS++) {
        char        Key[32];
        char const *s  = Vehicle_TireNo_Str(iS);
        double     *dv = NULL;

        /* key = <len0> <Frc0> <dFrc/dl> */
        sprintf(Key, "SFH.Spring%s", s);
        dv = iGetTable2(Inf, Key, 3, &n);
        if (dv != NULL) {
            mp->Spring[iS].len0    = dv[0];
            mp->Spring[iS].Frc0    = dv[1];
            mp->Spring[iS].dFrc_dl = dv[2];
            free(dv);
        } else {
            LogErrF(EC_Init, "%s: Unsupported argument for '%s'", MsgPre, Key);
            goto ErrorReturn;
        }

        /* key = <dF/dlp> */
        sprintf(Key, "SFH.Damp_Push%s", s);
        mp->Damp_Push[iS].dFrc_dlp = iGetDbl(Inf, Key);

        sprintf(Key, "SFH.Damp_Pull%s", s);
        mp->Damp_Pull[iS].dFrc_dlp = iGetDbl(Inf, Key);

        /* key = <len0>  <dFrc/dl> */
        sprintf(Key, "SFH.Buf_Push%s", s);
        dv = iGetTable2(Inf, Key, 2, &n);
        if (dv != NULL) {
            mp->Buf_Push[iS].len0    = dv[0];
            mp->Buf_Push[iS].dFrc_dl = dv[1];
            free(dv);
        } else {
            LogErrF(EC_Init, "%s: Unsupported argument for '%s'", MsgPre, Key);
            goto ErrorReturn;
        }

        sprintf(Key, "SFH.Buf_Pull%s", s);
        dv = iGetTable2(Inf, Key, 2, &n);
        if (dv != NULL) {
            mp->Buf_Pull[iS].len0    = dv[0];
            mp->Buf_Pull[iS].dFrc_dl = dv[1];
            free(dv);
        } else {
            LogErrF(EC_Init, "%s: Unsupported argument for '%s'", MsgPre, Key);
            goto ErrorReturn;
        }

        /* key = <dF/dl> */
        sprintf(Key, "SFH.Stabi%s", s);
        mp->Stabi[iS].dFrc_dl = iGetDbl(Inf, Key);
    }

    /* The following lines can be used if the parameters len0 of the spring are to be calculated to fit the static equilibrium */
    //    for (iS=0; iS < N_SUSPENSIONS; iS++)
    //	 Param[iS] = &mp->Spring[iS].len0;
    Susp_FrcSystem_GetCfgOutIF(Inf, CfgIF, ModelKind, Param);

    return mp;

ErrorReturn:
    if (mp != NULL) {
        free(mp);
    }
    return NULL;
}

static int
MyModel_Calc(void *MP, void *pIF, void *pIF2, double dt)
{
    tSusp_FrcSystemIF *IF = (tSusp_FrcSystemIF *) pIF;
    struct tMyModel   *mp = (struct tMyModel *) MP;
    int                iS;

    for (iS = 0; iS < N_SUSPENSIONS; iS++) {
        IF->FrcSpring[iS] = mp->Spring[iS].dFrc_dl * (mp->Spring[iS].len0 - IF->lSpring[iS]) + mp->Spring[iS].Frc0;

        if (IF->vDamper[iS] >= 0.0) {
            IF->FrcDamper[iS] = -mp->Damp_Pull[iS].dFrc_dlp * IF->vDamper[iS];
        } else {
            IF->FrcDamper[iS] = -mp->Damp_Push[iS].dFrc_dlp * IF->vDamper[iS];
        }

        IF->FrcBuffer[iS] = 0.0;
        if (IF->lBuffer[iS] < mp->Buf_Push[iS].len0) {
            IF->FrcBuffer[iS] = mp->Buf_Push[iS].dFrc_dl * (mp->Buf_Push[iS].len0 - IF->lBuffer[iS]);
        } else if (IF->lBuffer[iS] > mp->Buf_Pull[iS].len0) {
            IF->FrcBuffer[iS] = -mp->Buf_Pull[iS].dFrc_dl * (IF->lBuffer[iS] - mp->Buf_Pull[iS].len0);
        }
    }

    for (iS = 0; iS < N_SUSPENSIONS; iS += 2) {
        /* Frc = c * (right - left) */
        IF->FrcStabi[iS]     = mp->Stabi[iS].dFrc_dl * (IF->lStabi[iS + 1] - IF->lStabi[iS]);
        IF->FrcStabi[iS + 1] = -IF->FrcStabi[iS];
    }

    return 0;
}

static void
MyModel_Delete(void *MP, char const *Ident)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    if (mp != NULL) {
        free(mp);
    }
    mp = NULL;
}

int
Susp_FrcSystem_Register_MyModel(void)
{
    tModelClassDescr m;

    memset(&m, 0, sizeof(m));
    m.VersionId  = ThisVersionId;
    m.New        = MyModel_New;
    m.Calc       = MyModel_Calc;
    m.Delete     = MyModel_Delete;
    m.DeclQuants = MyModel_DeclQuants;
    /* Should only be used if the model doesn't read params from extra files */
    m.ParamsChanged = ParamsChanged_IgnoreCheck;

    return Model_Register(ModelClass_Susp_FrcSystem, ThisModelKind, &m);
}
