/*
 *****************************************************************************
 *  CarMaker - Version 15.0
 *  Virtual Test Driving Tool
 *
 *  Copyright ©1998-2025 IPG Automotive GmbH. All rights reserved.
 *  www.ipg-automotive.com
 *****************************************************************************
 *
 * Simple VehicleControl Model to demonstrate the manipulation of Driver Gas
 *
 * Add the declaration of the register function to one of your header files,
 * for example to User.h and call it in User_Register()
 *
 *    VehicleControl_Register_MyModel ()
 *
 *****************************************************************************
 */

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "CarMaker.h"
#include "Car/Vehicle_Car.h"
#include "MyModels.h"

struct tMyModel {
    /* parameters of MyVehicleControl */
    double GasFac;

    /* variables of MyVehicleControl */
    double Gas;
};

static char const ThisModelClass[] = "VehicleControl";
static char const ThisModelKind[]  = "MyModel";
static int const  ThisVersionId    = 1;

/******************************************************************************/

static void
MyModel_DeclQuants_dyn(struct tMyModel *mp, int park)
{
    static struct tMyModel MyModel_Dummy = {0};
    if (park) {
        mp = &MyModel_Dummy;
    }

    /* Define here dict entries for dynamically allocated variables. */

    DDefDouble4(NULL, "MyVehicleControl.Gas", "", &mp->Gas, DVA_None);
}

static void
MyModel_DeclQuants(void *MP, char const *Ident)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    if (mp == NULL) {
        /* Define here dict entries for non-dynamically allocated (static) variables. */

    } else {
        MyModel_DeclQuants_dyn(mp, 0);
    }
}

static int
MyModel_Calc(void *MP, void *pIF, void *pIF2, double dt)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    /* Manipulation of VehicleControl */
    mp->Gas            = mp->GasFac * VehicleControl.Gas;
    VehicleControl.Gas = mp->Gas;

    return 0;
}

static void *
MyModel_New(struct tInfos *Inf, void *pCfg, char const *KindKey, char const *IdKey)
{
    struct tMyModel *mp = NULL;
    char const      *ModelKind, *key;
    char             MsgPre[64];
    int              VersionId = 0;

    if ((ModelKind = SimCore_GetKindInfo(Inf, ModelClass_VehicleControl, KindKey, 0, ThisVersionId, &VersionId))
        == NULL) {
        return NULL;
    }

    mp = (struct tMyModel *) calloc(1, sizeof(*mp));

    sprintf(MsgPre, "%s %s", ThisModelClass, ThisModelKind);

    key        = "MyVC.GasFac";
    mp->GasFac = iGetDbl(Inf, key);
    if (mp->GasFac < 0.0 || mp->GasFac > 1.0) {
        LogErrF(EC_Init, "%s: gas factor '%s' must be 0...1", MsgPre, key);
        goto ErrorReturn;
    }

    return mp;

ErrorReturn:
    free(mp);
    return NULL;
}

static void
MyModel_Delete(void *MP, char const *Ident)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    /* Park the dict entries for dynamically allocated variables before deleting */
    MyModel_DeclQuants_dyn(mp, 1);
    free(mp);
}

int
VehicleControl_Register_MyModel(void)
{
    tModelClassDescr m;

    memset(&m, 0, sizeof(m));
    m.VersionId  = ThisVersionId;
    m.New        = MyModel_New;
    m.Calc       = MyModel_Calc;
    m.DeclQuants = MyModel_DeclQuants;
    m.Delete     = MyModel_Delete;
    /* Should only be used if the model doesn't read params from extra files */
    m.ParamsChanged = ParamsChanged_IgnoreCheck;

    return Model_Register(ModelClass_VehicleControl, ThisModelKind, &m);
}
