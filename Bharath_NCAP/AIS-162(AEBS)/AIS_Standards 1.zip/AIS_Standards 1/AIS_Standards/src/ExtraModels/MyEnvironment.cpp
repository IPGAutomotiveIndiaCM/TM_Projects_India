/*
 *****************************************************************************
 *  CarMaker - Version 15.0
 *  Virtual Test Driving Tool
 *
 *  Copyright ©1998-2025 IPG Automotive GmbH. All rights reserved.
 *  www.ipg-automotive.com
 *****************************************************************************
 *
 * Simple environment Model
 *
 * Add the declaration of the register function to one of your header files,
 * for example to User.h and call it in User_Register())
 *
 *    Environment_Register_MyModel ();
 *
 *****************************************************************************
 */

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "CarMaker.h"
#include "Car/Vehicle_Car.h"
#include "Environment.h"
#include "MyModels.h"

static char const ThisModelKind[] = "MyEnvironment";
static int const  ThisVersionId   = 1;

struct tMyModel {
    /* Parameters */
    double Temp;     /* Air temperature [K]   */
    double Pressure; /* Air pressure    [bar] */
};

static void
MyModel_DeclQuants_dyn(struct tMyModel *mp, int park)
{
    static struct tMyModel MyModel_Dummy = {0};
    if (park) {
        mp = &MyModel_Dummy;
    }

    /* Define here dict entries for dynamically allocated variables. */
}

static void
MyModel_DeclQuants(void *MP, char const *Ident)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    if (mp == NULL) {
        /* Define here dict entries for non-dynamically allocated (static) variables. */

    } else {
        MyModel_DeclQuants_dyn(mp, 0);
    }
}

static void *
MyModel_New(tInfos *Inf, void *pCfg, char const *KindKey, char const *IdKey)
{
    struct tMyModel *mp = NULL;
    char const      *ModelKind;
    int              VersionId = 0;

    if ((ModelKind = SimCore_GetKindInfo(Inf, ModelClass_Environment, KindKey, 0, ThisVersionId, &VersionId)) == NULL) {
        return NULL;
    }

    mp = (struct tMyModel *) calloc(1, sizeof(*mp));

    mp->Temp     = iGetDblOpt(Inf, "Env.MyEnvironment.Temp", 293.15);
    mp->Pressure = iGetDblOpt(Inf, "Env.MyEnvironment.Pressure", 1.013);

    return mp;
}

static int
MyModel_Calc(void *MP, void *pIF, void *pIF2, double dt)
{
    tEnvironmentIF  *IF = (tEnvironmentIF *) pIF;
    struct tMyModel *mp = (struct tMyModel *) MP;

    IF->Temperature = mp->Temp;
    IF->AirPressure = mp->Pressure;

    return 0;
}

static void
MyModel_Delete(void *MP, char const *Ident)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    /* Park the dict entries for dynamically allocated variables before deleting */
    MyModel_DeclQuants_dyn(mp, 1);
    free(mp);
}

int
Environment_Register_MyModel(void)
{
    tModelClassDescr m;

    memset(&m, 0, sizeof(m));
    m.VersionId  = ThisVersionId;
    m.New        = MyModel_New;
    m.Calc       = MyModel_Calc;
    m.Delete     = MyModel_Delete;
    m.DeclQuants = MyModel_DeclQuants;
    /* Should only be used if the model doesn't read params from extra files */
    m.ParamsChanged = ParamsChanged_IgnoreCheck;

    return Model_Register(ModelClass_Environment, ThisModelKind, &m);
}
