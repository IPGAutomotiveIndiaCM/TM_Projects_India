/*
 *****************************************************************************
 *  CarMaker - Version 15.0
 *  Virtual Test Driving Tool
 *
 *  Copyright ©1998-2025 IPG Automotive GmbH. All rights reserved.
 *  www.ipg-automotive.com
 *****************************************************************************
 *
 * Simple driveline OpenXWD Model
 *
 * Add the declaration of the register function to one of your header files,
 * for example to User.h and call it in User_Register()
 *
 *    DriveLineXWD_Register_MyModel ();
 *
 *****************************************************************************
 */

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "CarMaker.h"
#include "Car/Vehicle_Car.h"
#include "MyModels.h"

#define NWHEEL 4

static char const ThisModelClass[] = "PowerTrain.DLXWD";
static char const ThisModelKind[]  = "MyModel";
static int const  ThisVersionId    = 1;

struct tMyModel {
    int nWheels;
};

static void
MyModel_DeclQuants(void *MP, char const *Ident)
{
}

/* Model output parameters in the configuration struct CfgIF, which are required
   by CarMaker, are read in before the MyModel_New() function.
   - The parametrization of these parameters is supported by the GUI.
   - These output parameters can be used internally by the model in same way like
     the input parameters
 */
static void *
MyModel_New(struct tInfos *Inf, void *pCfgIF, char const *KindKey, char const *IdKey)
{
    tPTDriveLineXWD_CfgIF *CfgIF = (tPTDriveLineXWD_CfgIF *) pCfgIF;
    struct tMyModel       *mp    = NULL;
    char                   MsgPre[64];
    char const            *ModelKind;
    int                    VersionId = 0;

    if ((ModelKind = SimCore_GetKindInfo(Inf, ModelClass_PTDriveLineXWD, KindKey, 0, ThisVersionId, &VersionId))
        == NULL) {
        return NULL;
    }

    mp = (struct tMyModel *) calloc(1, sizeof(*mp));

    sprintf(MsgPre, "%s %s", ThisModelClass, ThisModelKind);

    /* get CfgIF parameters */
    if (DriveLineXWD_GetCfgOutIF(Inf, CfgIF, ModelKind) != 0) {
        goto ErrorReturn;
    }

    /* CfgIF -> Model */
    mp->nWheels = CfgIF->nWheels;
    if (mp->nWheels != NWHEEL) {
        LogErrF(EC_Init, "%s: model supports only a four wheel vehicle", MsgPre);
        goto ErrorReturn;
    }

    /* CfgIF output: verification if the parametrization by the GUI corresponds to the model */
    if (CfgIF->iDiff_mean <= 0) {
        LogErrF(EC_Init, "%s: mean driveline ratio must be positive and non zero", MsgPre);
        goto ErrorReturn;
    }

    return mp;

ErrorReturn:
    free(mp);
    return NULL;
}

static int
MyModel_Calc(void *MP, void *pIF, void *pIF2, double dt)
{
    tPTDriveLineXWD_IF          *IF    = (tPTDriveLineXWD_IF *) pIF;
    tPTDriveLineXWD_CfgIF const *CfgIF = IF->CfgIF;
    double                       Trq;
    int                          iS;

    for (iS = 0; iS < 2; iS++) {
        Trq                        = IF->DriveIn.Trq_in;
        IF->WheelOut[iS].Trq_Drive = Trq * 0.5 * CfgIF->iDiff_mean;
    }
    for (iS = 2; iS < NWHEEL; iS++) {
        IF->WheelOut[iS].Trq_Drive = 0;
    }

    IF->DriveOut.rotv_in = (IF->WheelIn[0].rotv + IF->WheelIn[1].rotv) * 0.5 * CfgIF->iDiff_mean;

    for (iS = 0; iS < NWHEEL; iS++) {
        IF->WheelOut[iS].Trq_Supp2WC = -IF->WheelOut[iS].Trq_Drive;
    }

    return 0;
}

static void
MyModel_Delete(void *MP, char const *Ident)
{
    struct tMyModel *mp = (struct tMyModel *) MP;

    free(mp);
}

int
DriveLineXWD_Register_MyModel(void)
{
    tModelClassDescr m;

    memset(&m, 0, sizeof(m));
    m.VersionId  = ThisVersionId;
    m.New        = MyModel_New;
    m.Calc       = MyModel_Calc;
    m.Delete     = MyModel_Delete;
    m.DeclQuants = MyModel_DeclQuants;
    /* Should only be used if the model doesn't read params from extra files */
    m.ParamsChanged = ParamsChanged_IgnoreCheck;

    return Model_Register(ModelClass_PTDriveLineXWD, ThisModelKind, &m);
}
