/*
 *****************************************************************************
 *  CarMaker - Version 15.0
 *  Virtual Test Driving Tool
 *
 *  Copyright ©1998-2025 IPG Automotive GmbH. All rights reserved.
 *  www.ipg-automotive.com
 *****************************************************************************
 *
 *  Functions
 *  ---------
 *
 *		ExitFcn ()
 *		App_Init_First ()
 *		App_Init_Second ()
 *		App_Init ()
 *		App_Register ()
 *		App_DeclQuants ()
 *		App_TestRun_Start_StaticCond_Calc ()
 *		App_TestRun_Start ()
 *		App_TestRun_Start_Finalize ()
 *		App_TestRun_Snapshot_Take ()
 *		App_TestRun_Calc ()
 *		App_TestRun_Calc_Part ()
 *		App_TestRun_End ()
 *		App_ShutDown ()
 *		App_End ()
 *		App_Cleanup ()
 *
 *		MainThread_Init ()
 *		MainThread_BeginCycle ()
 *		MainThread_DoCycle ()
 *		MainThread_FinishCycle ()
 *
 *	main ()
 *		CM_Main_Begin ()			(CM4SL)
 *		CM_Main_End ()				(CM4SL)
 *
 *
 * Special options for debugging
 * - DeltaT = const = SimCore.DeltaT
 * - Initialisation not in a second Thread
 *
 *****************************************************************************
 */

/******************************************************************************
 * +++ ATTENTION +++ ATTENTION +++ ATTENTION +++ ATTENTION +++ ATTENTION +++
 *
 *     Please, don't modify this file!
 *
 * +++ ATTENTION +++ ATTENTION +++ ATTENTION +++ ATTENTION +++ ATTENTION +++
 ******************************************************************************
 */

#include <Global.h>

#if defined(WIN32)
# include <winsock2.h>
# include <windows.h>
# include <process.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <errno.h>

#if defined(XENO)
# include <math.h>
# include <unistd.h>
# include <alchemy/task.h>
# include <alchemy/timer.h>
#endif
#if defined(XENO)
# include <RTGuard.h>
#endif

#include <CarMaker.h>
#include <TCPU.h>
#include <ModelManager.h>
#include <RemoteModelAccess.h>
#include <Vehicle/Sensor_Inertial.h>
#include <Vehicle/Sensor_SAngle.h>
#include <Vehicle/Sensor_Object.h>
#include <Vehicle/Sensor_FSpace.h>
#include <Vehicle/Sensor_Road.h>
#include <Vehicle/Sensor_TSign.h>
#include <Vehicle/Sensor_Line.h>
#include <Vehicle/Sensor_Collision.h>
#include <Vehicle/Sensor_GNav.h>
#include <Vehicle/PylonDetect.h>
#include <Vehicle/Sensor_Radar.h>
#include <Vehicle/Surrounding.h>
#include <Vehicle/Sensor_USonicRSI.h>
#include <Vehicle/Sensor_RadarRSI.h>
#include <Vehicle/Sensor_LidarRSI.h>
#include <Vehicle/Sensor_CameraRSI.h>
#include <Vehicle/Sensor_Camera.h>
#include <Vehicle/Sensor_ObjectByLane.h>
#include <Vehicle/Sensor_GroundTruth.h>
#include <Vehicle/Sensor_Assembly.h>

# include <Car/Brake.h>
# include <Car/Trailer_Brake.h>

#include <CycleControl.h>

#include "adtf.h"
#include "ADASRP.h"

#include "User.h"
#include "IOVec.h"
#include <ioconf.h>

#include <CM_XCP.h>
#include <CM_CCP.h>
#include <rbs.h>
#include <sip_rbs.h>

#include "FMUQueue_IF.h"

#include <SimNet.h>
#include <DrivingSim.h>


/*** Time Synchronisation	***********************************************/

static void
ProcessApoMessages(void)
{
    char MsgBuf[APO_ADMMAX];
    int  ch, len, who;

    while (AposGetAppMsgFrom(&ch, &MsgBuf, &len, &who) != 0) {
        if (CM_XCP_ApoMsg_Eval(ch, MsgBuf, len) >= 0) {
            continue;
        }
        if (CM_CCP_ApoMsg_Eval(ch, MsgBuf, len) >= 0) {
            continue;
        }
        if (ADTF_ApoMsg_Eval(ch, MsgBuf, len) >= 0) {
            continue;
        }
        if (User_ApoMsg_Eval(ch, MsgBuf, len, who) < 0 && SimCore_ApoMsg_Eval(ch, MsgBuf, len, who) < 0) {
            SimCore_UnknownApoMsgWarn(ch, MsgBuf, len);
        }
    }
}

static void
GatherGPUSensorInstances(void)
{
    double const timeout_s = SimCore_GPUSensor_GetGatherTimeout();
    double const tstart    = SysGetTime();

    while (!SimCore_GPUSensor_MinInstRegistered()) {
        if (SimCore.OnlyOneSimulation || CMTh_AttribGet(CMTh_Kind_TestRun_Start, CMTh_Attrb_MultiThread)) {
#if !defined(CM_HIL) && !defined(CM4SL)
            if (AposWaitIO(50)) {
                AposPoll(SimCore.AposPollTime);
                ProcessApoMessages();
            }
#else
            SysUSleep(50000);
            AposPoll(SimCore.AposPollTime);
            ProcessApoMessages();
#endif
        } else {
            SysUSleep(50000);
        }
        if (SysGetTime() - tstart > timeout_s) {
            break;
        }
    }
    SimCore_GPUSensor_PrintSensorInfo();
}

/*
 * ExitFcn ()
 *
 * Fast exit in special situations (signal handler, emergency loop).
 */

static int
ExitFcn(void)
{
    IO_Cleanup();
    AposExit();
    SysSSleep(0.5);
    LogCleanup();
    CMTh_Cleanup();
    SysCleanup();
    return 0;
}

/*** ***	***************************************************************/

/*
 * App_Init_First ()
 *
 */

static int
App_Init_First(int argc, char **argv)
{
    SysInit();
    SysNonStdMath();

    CMTh_Init();
    LogInitSingleThread("@LogBuffer@");

    SimCore_Init_First(argc, argv);

    IO_Init_First();
    IOConf_Init_First();
    RBS_Init_First();
    SIP_Init_First();

    User_Init_First();
    CM_XCP_Init_First(NULL);
    CM_CCP_Init_First(NULL);
    return 0;
}

/*
 * App_Init_Second ()
 *
 */

static int
App_Init_Second(void)
{
    SimCore_Apo_SetAppClass("TruckMaker");
    SimCore_Apos_Init_First(32, 0, 0xffffffff);
    SimCore_Apo_SetStateInfo("Application is starting ...");

    if (SimCore_Init() < 0) {
        return -1;
    }
    return 0;
}

/*
 * App_Init ()
 *
 */

static int
App_Init(void)
{
    ExtInp_Init();
    Env_Init();
    TrfLight_Init();
    DrivMan_Init();
    VehicleControl_Init();
    Vhcl_Init();
    Traffic_Init();
    PylonDetect_Init();
    BdyFrame_Init();
    InertialSensor_Init();
    SAngleSensor_Init();
    ADTF_Init();
    ObjectSensor_Init();
    FSpaceSensor_Init();
    RoadSensor_Init();
    TSignSensor_Init();
    LineSensor_Init();
    RadarSensor_Init();
    CollisionSensor_Init();
    GNavSensor_Init();
    USonicRSI_Init();
    RadarRSI_Init();
    LidarRSI_Init();
    ObjByLane_Init();
    CameraSensor_Init();
    CameraRSI_Init();
    GroundTruthSensor_Init();
    SensorAssembly_Init();
#if defined(CM_HIL)
    FST_Init(SimCore.TestRig.ECUParam.Inf);
#endif
    IOConf_Param_Get();
    if (RBS_Param_Get(SimCore.TestRig.ECUParam.Inf, NULL) != 0) {
        return -1;
    }
    if (SIP_Param_Get(SimCore.TestRig.ECUParam.Inf, NULL) != 0) {
        return -1;
    }
    if (IO_Init() < 0) {
        return -1;
    }
    if (IOConf_Init() < 0) {
        return -1;
    }
    if (User_Init() < 0) {
        return -1;
    }
    if (CM_XCP_Init() != 0 || CM_CCP_Init() != 0 || RBS_Init() != 0 || SIP_Init() != 0) {
        return -1;
    }

    Plugins_Init();

    return 0;
}

/*
 * App_Register ()
 *
 */

static int
App_Register(void)
{
    Vhcl_Register();
    User_Register();
    return 0;
}

/*
 * App_DeclQuants ()
 *
 * Add quantities to the data dictionary (can be displayed, saved)
 * and export configuration
 */

static int
App_DeclQuants(void)
{
    SimCore_DeclQuants();
    Env_DeclQuants();
    TrfLight_DeclQuants();
    DrivMan_DeclQuants();
    VehicleControl_DeclQuants();
    Vhcl_DeclQuants();
    User_DeclQuants();
    CM_XCP_DeclQuants();
    CM_CCP_DeclQuants();
    RBS_DeclQuants();
    SIP_DeclQuants();
    IOConf_DeclQuants();
    App_ExportConfig();
    return 0;
}

/*
 * App_TestRun_Start_StaticCond_Calc ()
 *
 */

static int
App_TestRun_Start_StaticCond_Calc(void)
{
    int rv = 0;

    if (SimCore_TestRun_Start_StaticCond_Calc() < 0) {
        rv = -1;
    }

    if (Vhcl_StaticCond_Calc() < 0) {
        rv = -2;
    }

    if (User_TestRun_Start_StaticCond_Calc() < 0) {
        rv = -3;
    }

    return rv;
}

/*
 * App_TestRun_Start ()
 *
 */

static void *
App_TestRun_Start(void *arg)
{
    int rv     = 0;
    int nError = Log_nError;

    /* Send connect request to movies and wait for them to connect*/
    SimCore_GPUSensor_TriggerMovies(SimCore.TestRun.Options);
    GatherGPUSensorInstances();
    if (!SimCore.Reconfig.Active) {
        if (SimCore_TestRun_Start() < 0) {
            rv = -1;
            goto ErrorReturn;
        }
    } else {
        /* Save vehicle state for reconfiguration */
        if (Vehicle_Reconfig() < 0) {
            rv = -26;
            goto ErrorReturn;
        }

        /* Delete Animation Message buffer */
        SimCore_Anim_DeleteMsgBuf();

        /* Delete all parts which are reconfigurated */
        Vhcl_Delete(0);
        VehicleControl_Delete();
        PylonDetect_Delete();

        /* Restart initialization of vehicle */
        if (SimCore_Vehicle_Start() < 0) {
            rv = -1;
            goto ErrorReturn;
        }
    }
    if (SimCore.TestRig.ECUParam.WasRead) {
        if (CM_XCP_Param_Get(SimCore.TestRig.ECUParam.Inf, "XCP") != 0) {
            rv = -6;
        }
        if (CM_CCP_Param_Get(SimCore.TestRig.ECUParam.Inf, "CCP") != 0) {
            rv = -7;
        }
    }

    /* Delete all body frames for body sensor calculation before new registration */
    BdyFrame_Delete();

    if (User_TestRun_Start_atBegin() < 0) {
        rv = -2;
        goto ErrorReturn;
    }

    if (!SimCore.Reconfig.Active && ADASRP_StartClient() != 0) {
        rv = -3;
        goto ErrorReturn;
    }

    if (Env_New() < 0) {
        rv = -5;
        goto ErrorReturn;
    }
    if (SimCore_TestRun_Start_SessionCmds() != 0) {
        rv = -5;
        goto ErrorReturn;
    }
    if (!SimCore.Reconfig.Active && ExtInp_File_New() < 0) {
        rv = -4;
        goto ErrorReturn;
    }
    if (TrfLight_New() < 0) {
        rv = -6;
        goto ErrorReturn;
    }

    if (!SimCore.Reconfig.Active && DrivMan_New_PreVhcl() < 0) {
        rv = -7;
        goto ErrorReturn;
    }

    /* Vhcl_New() has to be called before DrivMan_New()
       (Vehicle.Cfg.UseIt, ...) */
    if (Vhcl_New() < 0) {
        rv                   = -8;
        SimCore.Vhcl.IsReady = 0;
        goto ErrorReturn;
    } else {
        SimCore.Vhcl.IsReady = 1;
    }

    if (DrivMan_Routing_New() < 0) {
        rv = -46;
        goto ErrorReturn;
    }

    if (Traffic_New(SimCore.TestRun.Inf, Env.Road) < 0) {
        rv = -9;
        goto ErrorReturn;
    }

    /* SimCore_GPUSensor_New() has to be called before Sensor*New() functions */
    if (SimCore_GPUSensor_New() < 0) {
        rv = -43;
        goto ErrorReturn;
    }

    /* SensorAssembly_New() has to be called before Sensor*New() functions */
    if (SensorAssembly_New() < 0) {
        rv = -44;
        goto ErrorReturn;
    }

    /* Surrounding_New() has to be called before any module (Radar, Camera, ...)
       calls the Surrounding_Register() function */
    if (Surrounding_New() < 0) {
        rv = -42;
        goto ErrorReturn;
    }
    if (InertialSensor_New() < 0) {
        rv = -10;
        goto ErrorReturn;
    }
    if (SAngleSensor_New() < 0) {
        rv = -29;
        goto ErrorReturn;
    }
    if (ObjectSensor_New() < 0) {
        rv = -11;
        goto ErrorReturn;
    }
    if (FSpaceSensor_New() < 0) {
        rv = -12;
        goto ErrorReturn;
    }
    if (RoadSensor_New() < 0) {
        rv = -13;
        goto ErrorReturn;
    }
    if (TSignSensor_New() < 0) {
        rv = -14;
        goto ErrorReturn;
    }
    if (LineSensor_New() < 0) {
        rv = -15;
        goto ErrorReturn;
    }
    if (CollisionSensor_New() < 0) {
        rv = -16;
        goto ErrorReturn;
    }
    if (RadarSensor_New() < 0) {
        rv = -30;
        goto ErrorReturn;
    }

    if (GNavSensor_New() < 0) {
        rv = -27;
        goto ErrorReturn;
    }
    if (PylonDetect_New() < 0) {
        rv = -17;
        goto ErrorReturn;
    }
    if (USonicRSI_New() < 0) {
        rv = -31;
        goto ErrorReturn;
    }
    if (RadarRSI_New() < 0) {
        rv = -32;
        goto ErrorReturn;
    }
    if (LidarRSI_New() < 0) {
        rv = -36;
        goto ErrorReturn;
    }
    if (CameraRSI_New() < 0) {
        rv = -37;
        goto ErrorReturn;
    }
    if (ObjByLane_New() < 0) {
        rv = -38;
        goto ErrorReturn;
    }
    if (CameraSensor_New() < 0) {
        rv = -40;
        goto ErrorReturn;
    }
    if (GroundTruthSensor_New() < 0) {
        rv = -41;
        goto ErrorReturn;
    }

    // SimCore_GPUSensor_SendVisClientCfg() has to be called after all sensors' initialization,
    // as the sensor clusters must be already registered and assigned.
    SimCore_GPUSensor_SendVisClientCfg();

    if (VehicleControl_New(SimCore.TestRun.Inf) < 0) {
        rv = -20;
        goto ErrorReturn;
    }
    if (!SimCore.Reconfig.Active && DrivMan_New() < 0) {
        rv = -18;
        goto ErrorReturn;
    } else if (SimCore.Reconfig.Active && DrivMan_Reconfig() < 0) {
        rv = -19;
        goto ErrorReturn;
    }

    if (Traffic_New_SmartGen(SimCore.TestRun.Inf) < 0) {
        rv = -45;
        goto ErrorReturn;
    }

    SimCore_TestRun_Start_atEnd();

    if (User_TestRun_Start_atEnd() < 0) {
        rv = -21;
        goto ErrorReturn;
    }

    if (CM_XCP_TestRun_Start(NULL, NULL) != 0) {
        rv = -22;
        goto ErrorReturn;
    }
    if (CM_CCP_TestRun_Start(NULL, NULL) != 0) {
        rv = -23;
        goto ErrorReturn;
    }

    if (Plugins_New() < 0) {
        rv = -28;
        goto ErrorReturn;
    }

    if (SimCore.NextState >= SCState_End) {
        goto OkReturn; /* initialization has been terminated ahead of time */
    }

    /*** model check pre */
    if (AppStartInfo.ModelCheck & AppStart_ModelCheck_BeforePre) {
        if (Vhcl_ModelCheck_BeforePre(SimCore.ModelCheck.Inf) < 0) {
            rv = -34;
            goto ErrorReturn;
        }
        if ((AppStartInfo.ModelCheck &= ~AppStart_ModelCheck_BeforePre) == 0) {
            SimStop();
            goto OkReturn;
        }
    }

    if (SimCore.NextState >= SCState_End) {
        goto OkReturn; /* initialization has been terminated ahead of time */
    }

    /*** static conditions */
    if (App_TestRun_Start_StaticCond_Calc() != 0) {
        rv = -25;
        goto ErrorReturn;
    }

    /* Initialize ego vehicle routing with newly calculated static conditions */
    if (DrivMan_Routing_Start() < 0) {
        rv = -46;
        goto ErrorReturn;
    }

    // allocate and initialize the surrounding
    // has to be called after sensor and body frame initialization
    if (Surrounding_Allocate() < 0) {
        rv = -42;
        goto ErrorReturn;
    }

    if (SimCore.NextState >= SCState_End) {
        goto OkReturn; /* initialization has been terminated ahead of time */
    }

    /*** model check 2nd */
    if (AppStartInfo.ModelCheck & AppStart_ModelCheck_AfterPre) {
        if (Vhcl_ModelCheck_AfterPre(SimCore.ModelCheck.Inf) < 0) {
            rv = -35;
            goto ErrorReturn;
        }
        if ((AppStartInfo.ModelCheck &= ~AppStart_ModelCheck_AfterPre) == 0) {
            SimStop();
        }
    }

OkReturn:
    ADTF_UpdateMapping();
    if (SimCore_TestRun_Start_End() < 0) {
        goto ErrorReturn_2nd;
    }
    SimCore.Start.Ok = 1;
    goto DoReturn;

ErrorReturn:
    ADTF_UpdateMapping();
    SimCore_TestRun_Start_End();

ErrorReturn_2nd:
    /* gone to this target if SimCore_TestRun_Start_End() failed */
    if (nError == Log_nError) {
        /* error was detected, but not reported */
        LogErrF(EC_Init, "Failure occurred while starting %s (rv=%d)",
            AppStartInfo.ModelCheck ? "modelcheck" : "Test Run", rv);
    }
    SimCore.Reconfig.Active = 0;
    SimCore.Start.Ok        = 0;

DoReturn:
    if (SimCore.Start.Ok) {
        if (SimCore.NextState == SCState_Start           /* running in main loop    */
            || SimCore.NextState == SCState_StartWait) { /* running in start thread */
            SimCore_State_Set(SCState_StartWaitAnim);
        }
    } else {
        SimCore_State_Set(SCState_End);
    }
    SimCore.Start.Tid = 0;

    return NULL;
}

/*
 * App_TestRun_Start_Finalize ()
 *
 * called:
 * - last cycle of Test Run start phase
 * - RT context
 */

static int
App_TestRun_Start_Finalize(void)
{
    int rv = 0;

    if (User_TestRun_Start_Finalize() < 0) {
        rv = -1;
    }

    if (SimCore_TestRun_Start_Finalize() < 0) {
        rv = -2;
    }

    return rv;
}

/*
 * App_TestRun_Snapshot_Take ()
 */

static int
App_TestRun_Snapshot_Take(void)
{
    return Vhcl_Snapshot_Take();
}

/*
 * App_TestRun_Calc ()
 *
 * Return Values:
 *   0	ok
 *  >0	DrivMan wants to end simulation
 *  <0	error
 *
 * called:
 * - each cycle
 * - RT context
 */


static int
App_TestRun_Calc(double dt)
{
    int i;
    int rv = 0;

    if (Env_Calc(dt) < 0) {
        rv = -1;
    }

    if (TrfLight_Calc() < 0) {
        rv = -1;
    }
    TCPU_Section_TakeTS(SimCore.TS.Environment);

    if ((i = DrivMan_Calc(dt)) != 0) {
        if (i < 0) {
            rv = -2; /* := error	*/
        } else if (i == 1) {
            rv = 1;  /* := end	*/
        } else if (i == 2) {
            rv = 3;  /* := is idle	-> User_Check_IsIdle() */
        } else {     /* if (i > 0) */
            rv = 1;  /* := end	*/
        }
    }
    if (User_DrivMan_Calc(dt) < 0) {
        rv = -2;
    }
    TCPU_Section_TakeTS(SimCore.TS.DrivMan);

    if (Traffic_Calc(dt) < 0) {
        rv = -5;
    }
    if (User_Traffic_Calc(dt) < 0) {
        rv = -5;
    }

    Plugins_CalcBefore(DVA_DM, dt);
    DVA_HandleWriteAccess(DVA_DM);
    Plugins_CalcAfter(DVA_DM, dt);
    TCPU_Section_TakeTS(SimCore.TS.Traffic);

    if (VehicleControl_Calc() < 0) {
        rv = -6;
    }

    if (Traffic_Lighting_Calc(dt) < 0) {
        rv = -5;
    }

    Plugins_CalcBefore(DVA_VC, dt);
    DVA_HandleWriteAccess(DVA_VC);
    Plugins_CalcAfter(DVA_VC, dt);

    if (User_VehicleControl_Calc(dt) < 0) {
        rv = -6;
    }

    if (VehicleControl_CalcPost() < 0) {
        rv = -6;
    }

    TCPU_Section_TakeTS(SimCore.TS.VehicleControl);

    Brake.IF.Pedal = VehicleControl.Brake;
    Brake.IF.Park  = VehicleControl.BrakePark;
    for (i = 0; i < Vehicle_nTrailer; i++) {
        if (TrBrake_List[i] != NULL) {
            TrBrake_List[i]->IF.Pedal = VehicleControl.Brake;
            TrBrake_List[i]->IF.Park  = VehicleControl.BrakePark;
        }
    }

    if (Vhcl_Calc(dt) < 0) {
        rv = -3;
    }

    if (DrivMan_Routing_Calc() < 0) {
        rv = -46;
    }
    TCPU_Section_TakeTS(SimCore.TS.Routing);

    if (BdyFrame_Calc() < 0) {
        rv = -12;
    }

    if (InertialSensor_Calc(dt) < 0) {
        rv = -7;
    }
    if (SAngleSensor_Calc(dt) < 0) {
        rv = -17;
    }

    if (ObjectSensor_Calc(dt) < 0) {
        rv = -8;
    }
    if (FSpaceSensor_Calc(dt) < 0) {
        rv = -9;
    }
    if (RoadSensor_Calc(dt) < 0) {
        rv = -10;
    }
    if (TSignSensor_Calc(dt) < 0) {
        rv = -11;
    }
    if (LineSensor_Calc(dt) < 0) {
        rv = -14;
    }
    if (CollisionSensor_Calc(dt) < 0) {
        rv = -15;
    }
    if (GNavSensor_Calc(dt) < 0) {
        rv = -16;
    }
    if (PylonDetect_Calc(dt) < 0) {
        rv = -13;
    }
    if (RadarSensor_Calc(dt) < 0) {
        rv = -30;
    }
    if (USonicRSI_Calc(dt) < 0) {
        rv = -31;
    }
    if (RadarRSI_Calc(dt) < 0) {
        rv = -32;
    }
    if (LidarRSI_Calc(dt) < 0) {
        rv = -36;
    }
    if (ObjByLane_Calc(dt) < 0) {
        rv = -37;
    }
    if (CameraSensor_Calc(dt) < 0) {
        rv = -40;
    }
    if (CameraRSI_Calc(dt) < 0) {
        rv = -41;
    }
    if (GroundTruthSensor_Calc(dt) < 0) {
        rv = -42;
    }

    TCPU_Section_TakeTS(SimCore.TS.Sensors);

    UserCalcCalledByAppTestRunCalc = 1;
    if (User_Calc(dt) < 0) {
        rv = -4;
    }
    UserCalcCalledByAppTestRunCalc = 0;
    if (CM_XCP_Calc() != 0) {
        if (SimCore.State == SCState_StartSim) {
            SimCore.Start.IsReady = 0;
        }
    }
    if (CM_CCP_Calc() != 0) {
        if (SimCore.State == SCState_StartSim) {
            SimCore.Start.IsReady = 0;
        }
    }
    TCPU_Section_TakeTS(SimCore.TS.User);

    return rv;
}


/*
 * App_TestRun_End ()
 *
 * call always at end of Test Run
 * if SimCore.OnlyOneSimulation==0, models are ended at the beginning
 * of next Test Run
 */

static void *
App_TestRun_End(void *arg)
{
    /* Remark: Not called if reconfiguration of the vehicle during
       the simulation is active (SimCore.Reconfig.Active=1) */

    if (AppStartInfo.Snapshot & Snapshot_Take) {
        Vhcl_Snapshot_Export2Inf();
    }

    CM_XCP_TestRun_End();
    User_TestRun_End();
    ADASRP_StopClient();

    Vhcl_Delete(1);
    DrivMan_Delete();
    DrivMan_Routing_Delete();
    Traffic_Delete();
    PylonDetect_Delete();
    RoadSensor_Delete();
    TSignSensor_Delete();
    LineSensor_Delete();
    RadarSensor_Delete();
    CameraSensor_Delete();
    GroundTruthSensor_Delete();
    Surrounding_Cleanup();

    /* At the end free the Road-Handle after free all model own RoadEval-Handles before */
    Env_Delete();

    SimCore_TestRun_End();
    SimCore.End.Tid = 0;

    SimCore_Bench_LogStats();

    return NULL;
}


static int
App_ShutDown(int ShutDownForced)
{
    int       i;
    int const n = 1000; /* Max. n loops for testrig shut down */

    for (i = 0; i < n; i++) {
        if (User_ShutDown(ShutDownForced) == 1 || ShutDownForced) {
            break;
        }
        SysUSleep(10);
    }
    return 0;
}

/*
 * App_End ()
 *
 * called once before application exits
 */

static void
App_End(void)
{
    CM_XCP_End();
    CM_CCP_End();
    User_End();

    ADTF_End();
    DrivMan_Delete();
    ExtInp_File_Delete();
    TrfLight_Delete();
    Vhcl_Delete(0);
    VehicleControl_Delete();
    Traffic_Delete();
    PylonDetect_Delete();
    CollisionSensor_Delete();
    Env_Delete();

    SimCore_End();
}

/*
 * App_Cleanup ()
 *
 * called once before application exits
 */

static void
App_Cleanup(void)
{
    Plugins_Cleanup();
# if defined(CM_HIL)
    FST_Cleanup();
# endif
    CM_XCP_Cleanup();
    CM_CCP_Cleanup();
    RBS_Cleanup();
    SIP_Cleanup();
    IO_Cleanup();
    ADTF_Cleanup();
    User_Cleanup();
    IOConf_Cleanup();
    GroundTruthSensor_CleanUp();
    ObjectSensor_Cleanup();
    RadarSensor_CleanUp();
    FSpaceSensor_Cleanup();
    RoadSensor_Cleanup();
    TSignSensor_Cleanup();
    LineSensor_Cleanup();
    GNavSensor_Cleanup();
    SAngleSensor_Cleanup();
    InertialSensor_Cleanup();
    USonicRSI_Cleanup();
    RadarRSI_Cleanup();
    LidarRSI_Cleanup();
    CameraSensor_Cleanup();
    CameraRSI_Cleanup();
    Surrounding_Cleanup();
    BdyFrame_CleanUp();
    Traffic_Cleanup();
    Vhcl_Cleanup();
    DrivMan_Cleanup();
    Env_Cleanup();
    TrfLight_Cleanup();
    ExtInp_Cleanup();
    SimCore_Cleanup();
    LogCleanup();
    CMTh_Cleanup();
    SensorAssembly_Cleanup();

    AposPoll(0.0);
    AposExit();
}


/*** Main Program *************************************************************/

/*
 * MainThread_Init ()
 *
 * Initialize the main thread of the application
 */

static int
MainThread_Init(void)
{
    int rv     = 0;
    int nError = Log_nError;

    /* install signal handler */
    if (!AppStartInfo.DontHandleSignals) {
        SimCore_ConfigSignalHandler(ExitFcn);
    }

    /*** Parameters for the application
     * - initialize dictionary
     * - ...
     */
    if (App_Init() < 0) {
        rv = -1;
        goto EndReturn;
    }

    /*** Model Registration */
    if (App_Register() < 0) {
        rv = -1;
    }

    /*** Add quantities to the data dictionary (can be displayed, saved)
     *   and export configuration
     */
    if (App_DeclQuants() < 0) {
        rv = -1;
    }

    /*** finalize initialization:
     * - close dictionary
     * - export system configuration  ...
     */
    if (SimCore_Init_Finalize() < 0) {
        rv = -1;
    }


    /* everything ok until now? */
    if (nError != Log_nError && rv >= 0) {
        rv = -1;
    }
    if (rv < 0) {
        goto EndReturn;
    }

    /*** load idle parameters/Test Run or start the selected Test Run */
    if (AppStartInfo.TestRunName == NULL) {
        SimCore_State_Set(SCState_Start);
        SimCore_State_Switch();
        App_TestRun_Start(NULL);
        if (SimCore.Start.Ok) {
            App_TestRun_End(NULL);
            SimCore_State_Set(SCState_Idle);
            SimCore_State_Switch();
        }
    } else {
        SimCore.TestRun.OnErrSaveHist = AppStartInfo.OnErrSaveHist;
        SimCore.TestRun.SaveMode      = AppStartInfo.SaveMode;
        SimStart(SimCore.TestRun.Project, SimCore.TestRun.User, AppStartInfo.TestRunName, AppStartInfo.TestRunFName,
            AppStartInfo.TestRunVariation);
        SimCore_State_Switch();
        /* Attention: SimState is SCState_SimStart, no params loaded. */
    }

    if (IO_Init_Finalize() < 0) {
        rv = -1;
    }
    if (IOConf_Init_Finalize() < 0) {
        rv = -1;
    }
    if (CycControl_InitIO() < 0) {
        rv = -1;
    }

    RBS_MapQuants();
    SIP_MapQuants();
    IOConf_MapQuants();
    if (RBS_Start() != 0 || SIP_Start() != 0) {
        return -1;
    }

    if (SimCore.State == SCState_Idle) {
        char tmp[64];
        SimCore_Apo_SetStateInfo("Idle");
        LogSpecial(0, "IDLE", "%s", GetLocalDateStr(tmp, 12, "%H:%M:%S", NULL));
    }

    /* any errors up to now ? */
    if (nError != Log_nError && rv >= 0) {
        rv = -1;
    }

EndReturn:
    SimCore_Init_Loop();

    /* activate scheduling and priority */
    CMTh_SetHighPriority(CMTh_Kind_Main);

    return rv;
}

static int
MainThread_BeginCycle(unsigned long long CycleNo64)
{
    FMUQ_Recv();

    SimNet_WaitForSync();

    /*** wait until cycle time passed */
    if ((DeltaT = SimCore_WaitForNextLoop(CycleNo64)) <= 0) {
        return 1;
    }
    SimCore_UpdateCPUWorkload();

    SimCore_State_Switch();

    /*** Start Loop */
    TCPU_Section_TakeTS(SimCore.TS.LoopStart);
    DVA_SetTime(TimeGlobal, CycleNo64);
    IO_BeginCycle();

    if (!LogPoll(TimeGlobal - SimCore.Start.TimeGlob)
        && ((SimCore.State > SCState_Start && SimCore.State < SCState_End) || SimCore.State == SCState_Pause)) {
        SimCore_State_Set(SCState_End);
        SimCore_State_Switch();
    }


    if (SimCore_InSyncWithVDS()) {
        /*** External inputs */
        if (SimCore.State == SCState_Simulate) {
            if (DrivMan_Calc_ExtInp() < 0) {
                return -1;
            }
        }
        ADASRP_Receive();

        /*** Input from hardware */
        IOConf_In((unsigned) CycleNo64);
        IO_In((unsigned) CycleNo64);
        RMA_In();
        RBS_In((unsigned) CycleNo64);
        SIP_In((unsigned) CycleNo64);
        CM_XCP_In();
        CM_CCP_In();
        Plugins_CalcBefore(DVA_IO_In, SimCore.DeltaT);
        DVA_HandleWriteAccess(DVA_IO_In);
        Plugins_CalcAfter(DVA_IO_In, SimCore.DeltaT);
        ADTF_In();
        SimNet_In();
        User_In((unsigned) CycleNo64);
        SessionCmds_Eval();

        SimCore_GPUSensor_Sync(ProcessApoMessages);
    }

    TCPU_Section_TakeTS(SimCore.TS.In);

    return 0;
}

static int
MainThread_DoCycle(unsigned long long CycleNo64)
{
    static int RampingDone;
    int        rv;

#if !defined(CM_HIL)
    if (SimCore.Anim.Sync_State != SyncOff && SimCore.State == SCState_Simulate) {
        if (SimCore_SyncVDS_Eval() != 0) {
            return 0; /* Skip cycle. */
        }
    }
#endif

    switch (SimCore.State) {
        case SCState_Start:
            /*** initialize Test Run start */
            SimCore_TestRun_Prepare();
            RampingDone = 0;

#if defined(XENO)
            RTGuard_Restart();
            SimCore.Cycle.nCTViolation = 0;
#endif
            User_Calc(DeltaT);
            SimCore_State_Set(SCState_StartWait);

            if (!SimCore.OnlyOneSimulation && CMTh_AttribGet(CMTh_Kind_TestRun_Start, CMTh_Attrb_MultiThread)) {
                SimCore.Start.Tid = 1;
                if ((rv = CMTh_Create(CMTh_Kind_TestRun_Start, App_TestRun_Start)) != 0) {
                    LogErrF(EC_General, "Can't create SimStart thread (err %d, %s)", rv, strerror(errno));
                    SimCore.Start.Tid = 0;
                }
            } else {
                App_TestRun_Start(NULL);
            }
            break;

        case SCState_StartWait:
            /* do nothing, wait for App_TestRun_Start() to return */
            User_Calc(DeltaT);
            break;

        case SCState_StartWaitAnim:
            User_Calc(DeltaT);
            if (SimCore.TimeWC <= SimCore.Anim.Wait_UntilWC) {
                if (SimCore_GPUSensor_AllReady() && SimCore_AnmWait_NoneRegistered()) {
                    SimCore_State_Set(SCState_StartSim);
                }
            } else {
                if (SimCore_GPUSensor_AllReady()) {
                    SimCore_State_Set(SCState_StartSim);
                } else {
                    SimCore_GPUSensor_LogTimeOut();
                    SimCore_State_Set(SCState_End);
                }
            }
            break;

        case SCState_StartSim:
            /* ramp up, start engine and wait until engine speed is stable */
            if (!RampingDone) {
                int nError = Log_nError;
                User_Calc(DeltaT);
                RampingDone = User_TestRun_RampUp(DeltaT);
                RampingDone = SimCore_TestRun_RampUp() && RampingDone;
                RampingDone = ADTF_IsReady() && RampingDone;
                if (Log_nError != nError) {
                    SimCore_State_Set(SCState_End);
                }
            } else {
                SimCore.Start.IsReady = 1;
                if (App_TestRun_Calc(DeltaT) < 0) {
                    SimCore_State_Set(SCState_End);
                }
                SimCore_TestRun_CheckReady();
                ADASRP_CheckReady();
            }

            if (SimCore.State == SimCore.NextState) {
                if (RampingDone && SimCore.Start.IsReady) {
                    SimCore_State_Set(SCState_StartLastCycle);
                } else {
                    if (SimCore.TimeWC - SimCore.Start.TimeWC > SimCore.Start.TimeLimit) {
                        LogErrF(EC_General, "Start hasn't finished within %g seconds." " Test Run aborted.",
                            SimCore.Start.TimeLimit);
                        SimCore_State_Set(SCState_End);
                    }
                }
            }
        break;

        case SCState_StartLastCycle:
            /* last pre-simulation calculation */
#if defined(XENO)
            RTGuard_Begin();
#endif
            if (App_TestRun_Calc(DeltaT) >= 0 && App_TestRun_Start_Finalize() >= 0) {
                SimCore_SyncVDS_Restart();
                SimCore_GPUSensor_Restart();
                SimCore_State_Set(SimCore.TAccel <= 0.01 ? SCState_Pause : SCState_Simulate);
                SimCore.Reconfig.Active = 0;
            } else {
                SimCore_State_Set(SCState_End);
            }
            TCPU_StartStats(SimCore.TCPU);
            break;

        case SCState_Idle:
            App_TestRun_Calc(DeltaT);
            break;

        case SCState_Simulate:
            if ((rv = App_TestRun_Calc(DeltaT)) != 0) {
                SimCore_State_Set(SCState_End);
            }
            break;

        case SCState_Pause:
            // wait for continue
            break;

        case SCState_End:
            if (SimCore.Start.Tid) {
                break;
            }
            SimCore.End.TimeWC = SimCore.TimeWC;
            TCPU_StopStats(SimCore.TCPU);
            User_Calc(DeltaT);
            User_TestRun_End_First();
            if (AppStartInfo.Snapshot & Snapshot_Take) {
                App_TestRun_Snapshot_Take();
            }

            QuantAudit_Finish();

            /* do GetIdle? skip GetIdle, if start wasn't ok or Skip is set */
            if (SimCore.Start.Ok) {
                SimCore_State_Set(SimCore.GetIdle.Skip ? SCState_EndIdleSet : SCState_EndIdleGet);
            } else {
                SimCore_State_Set(SCState_EndClean);
            }

            /* leave vehicle if error occurs */
            if (SimCore.Start.nError < Log_nError) {
                if (!DrivMan.OperatorActive) {
                    DrivMan.OperatorActive = 1;
                }
                DrivMan.OperationState_trg = OperState_Absent;
            }

            /* activate data storing? */
            if (Log_TriggerSave && SimCore.TestRun.OnErrSaveHist > 0) {
                DStoreSaveBegin(SimCore.Erg, SimCore.TestRun.OnErrSaveHist, 0);
            }

            /* end data storing: no additional data vectors */
            if (DStoreActive(SimCore.Erg)) {
                DStoreSaveEnd(SimCore.Erg, 0);
            }

            break;

        case SCState_EndIdleGet:
            /* run down the models into idle conditions (without a real simulation) */
            rv = App_TestRun_Calc(DeltaT);
            if (rv < 0) { /* error -> abort */
                SimCore_State_Set(SCState_EndIdleSet);
            }

            if (SimCore.TimeWC - SimCore.End.TimeWC - SimCore.GetIdle.TimeOffset > SimCore.GetIdle.TimeLimit) {
                LogErrF(EC_General, "Couldn't get idle within %g seconds. " "GetIdle aborted, ignition switched off.",
                    SimCore.GetIdle.TimeLimit);

                /* leave vehicle */
                if (!DrivMan.OperatorActive) {
                    DrivMan.OperatorActive = 1;
                }
                DrivMan.OperationState_trg = OperState_Absent;

                DStoreSaveEnd(SimCore.Erg, 1);
                SimCore_State_Set(SCState_EndIdleSet);
            }

            if (!User_Check_IsIdle(rv == 3)) {
                break;
            }

            /*** check data storage state */
            {
                long long bs, fs, ss;
                unsigned  dr;
                int       active;
                DStoreExtSaveStatus(SimCore.Erg, &bs, &fs, &ss, &dr, &active);

                if (active) {
                    static long long SavedSizeLast;
                    /* reset get idle time limit if storage is active and working */
                    if (SavedSizeLast != ss) {
                        SavedSizeLast              = ss;
                        SimCore.GetIdle.TimeOffset = SimCore.TimeWC - SimCore.End.TimeWC;
                    }
                    break;
                }
            }

            SimCore_State_Set(SCState_EndIdleSet);
            break;

        case SCState_EndIdleSet:
            App_TestRun_Calc(DeltaT);
            SimCore_State_Set(SCState_EndClean);
            break;

        case SCState_EndClean:
            User_Calc(DeltaT);
            SimCore_State_Set(SCState_EndWait);
            if (CMTh_AttribGet(CMTh_Kind_TestRun_End, CMTh_Attrb_MultiThread)) {
                SimCore.End.Tid = 1;
                if ((rv = CMTh_Create(CMTh_Kind_TestRun_End, App_TestRun_End)) != 0) {
                    LogErrF(EC_General, "Can't create end thread (returns %d, %s)", rv, strerror(errno));
                    SimCore.End.Tid = 0;
                }
            } else {
                App_TestRun_End(NULL);
            }
            break;

        case SCState_EndWait:
            User_Calc(DeltaT);
            /* Wait until App_TestRun_End() finished */
            if (SimCore.End.Tid) {
                break;
            }

#if defined(XENO)
            RTGuard_End();
#endif
            SimCore_State_Set(SCState_EndLastCycle);
            break;

        case SCState_EndLastCycle:
            User_Calc(DeltaT);

            if (SimCore.Shutdown.Request != ShutdownNot || SimCore.OnlyOneSimulation) {
                SimCore_State_Set(SCState_ShutDown);
            } else {
                SimCore_State_Set(SCState_Idle);
                SimCore_Apo_SetStateInfo("Idle");
            }
            break;

        case SCState_ShutDown:
            goto EndReturn;

        default:
            break;
    }
    return 0;

EndReturn:
    return 1;
}

static void
MainThread_FinishCycle(unsigned long long CycleNo64)
{
    /* output to the hardware */
    if (SimCore_InSyncWithVDS()) {
        TestMgrCmds_Eval();
        User_Out((unsigned) CycleNo64); /* -> IO */
        IOConf_OutMap();
        RBS_OutMap((unsigned) CycleNo64);
        SIP_OutMap((unsigned) CycleNo64);
        SimNet_Out();
        Plugins_CalcBefore(DVA_IO_Out, SimCore.DeltaT);
        DVA_HandleWriteAccess(DVA_IO_Out);
        Plugins_CalcAfter(DVA_IO_Out, SimCore.DeltaT);
        DrivingSim_Out();
        ADTF_Out();
        CM_XCP_Out((unsigned) CycleNo64);
        RBS_Out((unsigned) CycleNo64);
        SIP_Out((unsigned) CycleNo64);
        RMA_Out();
        IO_Out((unsigned) CycleNo64); /* IO -> Hardware */
        IOConf_Out((unsigned) CycleNo64);
        ADASRP_Send();

        if (SimCore.State == SCState_Simulate) {
            QuantAudit_Observe();
            /* output to file */
            if (SimCore.TestRun.SaveMode != 0 && DStorePutVec(SimCore.Erg) != 0) {
                LogWarnStr(EC_General, "DataStorage: SaveBuffer overflow. Storage is stopped.");
                if (!DStoreActive(SimCore.Erg)) {
                    DStoreSaveEnd(SimCore.Erg, 0);
                }
            }
        }
    }

    TCPU_Section_TakeTS(SimCore.TS.Out);

    /* APO-Server: Poll -- evaluate messages from clients */
    AposPoll(SimCore.AposPollTime);
    TCPU_Section_TakeTS(SimCore.TS.AposPoll);

    ProcessApoMessages();

    /* APO-Server: Send, generate and send messages to clients */
    CM_XCP_ApoMsg_Send(TimeGlobal, (unsigned) CycleNo64);
    CM_CCP_ApoMsg_Send(TimeGlobal, (unsigned) CycleNo64);
    User_ApoMsg_Send(TimeGlobal, (unsigned) CycleNo64);
    ADTF_ApoMsg_Send();
    SimCore_ApoMsg_Send(TimeGlobal, (unsigned) CycleNo64);

    TCPU_Section_TakeTS(SimCore.TS.AposEvalSend);

    SimCore_Bench_Eval();

#if defined(XENO)
    /* Check for switches to secondary mode */
    RTGuard_Eval();
#endif
}

/******************************************************************************/



/*
 * main ()
 *
 * main program
 */

int
main(int argc, char **argv)
{
    int nError;

    SimCore_Init_Locale();


    /*** First initialisation of basic modules/structures
     * - failures are not allowed
     * - lowlevel initialization
     */
    SimNet_ScanCmdLine(&argc, argv);
    SysInitRT("CarMaker", &argc, &argv);
    App_Init_First(argc, argv);
    nError = Log_nError;

    /*** evaluate command line */
    if ((argv = SimCore_ScanCmdLine(&argc, argv)) != NULL && (argv = User_ScanCmdLine(argc, argv)) != NULL) {
        if (argv[0] != NULL) {
            if (AppStartInfo.TestRunName != NULL) {
                free(AppStartInfo.TestRunName);
            }
            AppStartInfo.TestRunName = PathConv2IPN(argv[0]);
            SimCore_SetMultiThreadMode(0);
        }
    }

    /*** Second initialisation of modules/structures */
    if (App_Init_Second() < 0 || Log_nError > nError) {
        if (SimCore.OnlyOneSimulation) {
            return 1;
        }
        SimCore_MainThreadEmergency();
        return -1;
    }

    /* start the main application thread */
    if (MainThread_Init() >= 0) {
        unsigned long long CycleNo64 = 0;
        while (MainThread_BeginCycle(CycleNo64) == 0 && MainThread_DoCycle(CycleNo64) == 0) {
            MainThread_FinishCycle(CycleNo64);
            ++CycleNo64;
        }
    } else {
        if (!SimCore.OnlyOneSimulation) {
            SimCore_MainThreadEmergency();
        }
    }

    /* shut testrig down */
    App_ShutDown(0); /* shutdown desired	*/
    App_ShutDown(1); /* shutdown forced	*/

    /* end of application */
    App_End();
    App_Cleanup();

    return SimCore_Handle_AppRestart();
}



